import "./App.css";
import ConverterForm from "./componets/ConvertForm";

const App = () => {
  return (
    <div className="currency-converter">
      <h1 className="currency-title">Currency Converter</h1>
      <ConverterForm />
    </div>
  );
};

export default App;
